<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email    = $_POST['email'];
    $password = $_POST['password'];

    // --- Check if admin ---
    $adminCheck = mysqli_query($conn, "SELECT * FROM Admin WHERE Username='$email'");

    if (mysqli_num_rows($adminCheck) > 0) {
        $admin = mysqli_fetch_assoc($adminCheck); // fetch_assoc gets one row as array

        // Admin password is plain text (not hashed), so compare directly
        if ($password == $admin['Password']) {
            $_SESSION['admin_id'] = $admin['AdminID']; // remember admin is logged in
            $_SESSION['role']     = 'admin';
            header("Location: admin-dashboard.php");
            exit();
        }
    }

    // --- Check if student ---
    $result = mysqli_query($conn, "SELECT * FROM Student WHERE Email='$email'");

    if (mysqli_num_rows($result) > 0) {
        $student = mysqli_fetch_assoc($result);

        // password_verify checks the hashed password
        if (password_verify($password, $student['Password'])) {
            $_SESSION['student_id']   = $student['StudentID'];
            $_SESSION['student_name'] = $student['Name'];
            $_SESSION['role']         = 'student';
            header("Location: dashboard.php");
            exit();
        }
    }

    $error = "Wrong email or password!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav><h2>Campus Skill Match</h2></nav>

<div class="container">
    <form method="POST" action="login.php">
        <h2>Login</h2>

        <?php if (isset($error)) echo "<p style='color:red'>$error</p>"; ?>

        <input type="text" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit">Login</button>
        <p>No account? <a href="register.php">Register</a></p>
    </form>
</div>

</body>
</html>