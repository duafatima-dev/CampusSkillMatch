<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
include 'db.php';

// Delete student if delete link clicked
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM Student WHERE StudentID=$id");
}

$students = mysqli_query($conn, "SELECT StudentID, Name, Email, Department, Semester FROM Student");

$projects = mysqli_query($conn,
    "SELECT p.ProjectID, p.Title, p.Status, s.Name AS PostedBy
     FROM Project p
     JOIN Student s ON p.PostedBy = s.StudentID");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Data</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <h2>Admin Panel</h2>
    <ul><li><a href="admin-dashboard.php">Dashboard</a></li></ul>
</nav>

<div class="container">

    <h1>Students</h1>
    <table>
        <tr>
            <th>ID</th><th>Name</th><th>Email</th>
            <th>Department</th><th>Semester</th><th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($students)): ?>
        <tr>
            <td><?php echo $row['StudentID']; ?></td>
            <td><?php echo $row['Name']; ?></td>
            <td><?php echo $row['Email']; ?></td>
            <td><?php echo $row['Department']; ?></td>
            <td><?php echo $row['Semester']; ?></td>
            <td>
                <a href="manage-data.php?delete=<?php echo $row['StudentID']; ?>"
                   style="color:red">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <h1 style="margin-top:30px">Projects</h1>
    <table>
        <tr><th>ID</th><th>Title</th><th>Status</th><th>Posted By</th></tr>
        <?php while ($row = mysqli_fetch_assoc($projects)): ?>
        <tr>
            <td><?php echo $row['ProjectID']; ?></td>
            <td><?php echo $row['Title']; ?></td>
            <td><?php echo $row['Status']; ?></td>
            <td><?php echo $row['PostedBy']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

</div>
</body>
</html>