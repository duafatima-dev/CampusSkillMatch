<?php
session_start();
// If admin_id not in session → not logged in as admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <h2>Admin Panel</h2>
    <ul>
        <li><a href="post-project.php">Post Project</a></li>
        <li><a href="manage-data.php">Manage Data</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

<div class="container">
    <h1>Admin Dashboard</h1>
    <div class="grid">
        <div class="card">
            <h3>Post New Project</h3>
            <a class="btn" href="post-project.php">Open</a>
        </div>
        <div class="card">
            <h3>Manage Data</h3>
            <a class="btn" href="manage-data.php">Open</a>
        </div>
    </div>
</div>

</body>
</html>