<?php
session_start();

// If student_id is NOT in session, they're not logged in → send to login
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <h2>Campus Skill Match</h2>
    <ul>
        <li><a href="skills.php">Skills</a></li>
        <li><a href="browse.php">Projects</a></li>
        <li><a href="applications.php">Applications</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

<div class="container">

    <!-- $_SESSION['student_name'] was saved during login -->
    <h1>Welcome, <?php echo $_SESSION['student_name']; ?>!</h1>

    <div class="grid">
        <div class="card">
            <h3>Manage Skills</h3>
            <p>Add and update your skills.</p>
            <a class="btn" href="skills.php">Open</a>
        </div>
        <div class="card">
            <h3>Browse Projects</h3>
            <p>Find projects that match your skills.</p>
            <a class="btn" href="browse.php">Open</a>
        </div>
        <div class="card">
            <h3>Applications</h3>
            <p>Track your project applications.</p>
            <a class="btn" href="applications.php">Open</a>
        </div>
    </div>

</div>
</body>
</html>