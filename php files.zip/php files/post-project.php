<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title    = $_POST['title'];
    $desc     = $_POST['description'];
    $deadline = $_POST['deadline'];
    $skillID  = $_POST['skill_id'];
    $postedBy = $_POST['posted_by'];

    mysqli_query($conn,
        "INSERT INTO Project (Title, Description, Deadline, RequiredSkillID, PostedBy)
         VALUES ('$title', '$desc', '$deadline', $skillID, $postedBy)");

    $success = "Project posted!";
}

$skills   = mysqli_query($conn, "SELECT * FROM Skill");
$students = mysqli_query($conn, "SELECT StudentID, Name FROM Student");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Post Project</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <h2>Admin Panel</h2>
    <ul><li><a href="admin-dashboard.php">Dashboard</a></li></ul>
</nav>

<div class="container">
    <form method="POST" action="post-project.php">
        <h2>Post New Project</h2>

        <?php if (isset($success)) echo "<p style='color:green'>$success</p>"; ?>

        <input type="text" name="title"       placeholder="Project Title"       required>
        <textarea          name="description" placeholder="Description"         required></textarea>
        <input type="date" name="deadline"                                       required>

        <select name="skill_id" required>
            <option value="">-- Required Skill --</option>
            <?php while ($s = mysqli_fetch_assoc($skills)): ?>
                <option value="<?php echo $s['SkillID']; ?>"><?php echo $s['SkillName']; ?></option>
            <?php endwhile; ?>
        </select>

        <select name="posted_by" required>
            <option value="">-- Posted By --</option>
            <?php while ($st = mysqli_fetch_assoc($students)): ?>
                <option value="<?php echo $st['StudentID']; ?>"><?php echo $st['Name']; ?></option>
            <?php endwhile; ?>
        </select>

        <button type="submit">Post Project</button>
    </form>
</div>

</body>
</html>