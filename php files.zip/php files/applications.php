<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}
include 'db.php';
$studentID = $_SESSION['student_id'];

// Get all applications for this student with project title
$apps = mysqli_query($conn,
    "SELECT p.Title, a.Status, a.AppliedDate
     FROM Application a
     JOIN Project p ON a.ProjectID = p.ProjectID
     WHERE a.StudentID = $studentID");
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Applications</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <h2>Campus Skill Match</h2>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="skills.php">Skills</a></li>
        <li><a href="browse.php">Projects</a></li>
    </ul>
</nav>

<div class="container">
    <h1>My Applications</h1>

    <table>
        <tr>
            <th>Project</th>
            <th>Applied Date</th>
            <th>Status</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($apps)): ?>
        <tr>
            <td><?php echo $row['Title']; ?></td>
            <td><?php echo $row['AppliedDate']; ?></td>
            <td><?php echo $row['Status']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

</body>
</html>