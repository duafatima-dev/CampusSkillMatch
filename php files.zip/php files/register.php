<?php
session_start();   // start session so we can use $_SESSION later
include 'db.php';  // bring in the database connection

// Did the user click Submit?
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Grab what user typed in the form
    $name       = $_POST['name'];
    $email      = $_POST['email'];
    $department = $_POST['department'];
    $semester   = $_POST['semester'];

    // password_hash scrambles the password so it's safe to store
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if this email already exists in the database
    $check = mysqli_query($conn, "SELECT * FROM Student WHERE Email='$email'");

    if (mysqli_num_rows($check) > 0) {
        // num_rows counts how many rows were found
        $error = "Email already registered!";

    } else {
        // Insert the new student into the database
        $sql = "INSERT INTO Student (Name, Email, Password, Department, Semester)
                VALUES ('$name', '$email', '$password', '$department', '$semester')";

        mysqli_query($conn, $sql); // actually run the query

        // Send user to login page
        header("Location: login.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav><h2>Campus Skill Match</h2></nav>

<div class="container">

    <!-- method="POST" means form data goes to $_POST -->
    <!-- action="register.php" means send it to this same file -->
    <form method="POST" action="register.php">
        <h2>Create Account</h2>

        <!-- Show error in red if it exists -->
        <?php if (isset($error)) echo "<p style='color:red'>$error</p>"; ?>

        <!-- name="name" must match $_POST['name'] above -->
        <input type="text"   name="name"       placeholder="Full Name"        required>
        <input type="email"  name="email"      placeholder="Email"            required>
        <input type="password" name="password" placeholder="Password"         required>
        <input type="text"   name="department" placeholder="Department"       required>
        <input type="number" name="semester"   placeholder="Semester (1-8)"   min="1" max="8" required>

        <button type="submit">Register</button>
        <p>Already have an account? <a href="login.php">Login</a></p>
    </form>

</div>
</body>
</html>