<?php
$conn = mysqli_connect("localhost", "root", "", "campus skill match system");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>