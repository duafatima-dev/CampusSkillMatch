<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}
include 'db.php';

$studentID = $_SESSION['student_id']; // shorter variable for convenience

//Add a skill when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $skillID = $_POST['skill_id'];
    $level   = $_POST['level'];

    // Make sure student doesn't already have this skill
    $check = mysqli_query($conn, "SELECT * FROM Student_Skills
                                  WHERE StudentID=$studentID AND SkillID=$skillID");

    if (mysqli_num_rows($check) == 0) {
        mysqli_query($conn, "INSERT INTO Student_Skills (StudentID, SkillID, SkillLevel)
                             VALUES ($studentID, $skillID, '$level')");
    }
}

// --- Remove a skill when Remove link is clicked ---
if (isset($_GET['delete'])) {
    $delID = $_GET['delete']; // get skill id from URL
    mysqli_query($conn, "DELETE FROM Student_Skills
                         WHERE StudentID=$studentID AND SkillID=$delID");
}

// --- Get this student's skills (JOIN connects two tables) ---
$mySkills = mysqli_query($conn,
    "SELECT sk.SkillName, ss.SkillLevel, sk.SkillID
     FROM Student_Skills ss
     JOIN Skill sk ON ss.SkillID = sk.SkillID
     WHERE ss.StudentID = $studentID");

// --- Get all skills for the dropdown ---
$allSkills = mysqli_query($conn, "SELECT * FROM Skill");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Skills</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <h2>Campus Skill Match</h2>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="browse.php">Projects</a></li>
        <li><a href="applications.php">Applications</a></li>
    </ul>
</nav>

<div class="container">
    <h1>My Skills</h1>

    <form method="POST" action="skills.php">

        <!-- Dropdown of all skills from database -->
        <select name="skill_id" required>
            <option value="">-- Select Skill --</option>
            <?php while ($s = mysqli_fetch_assoc($allSkills)): ?>
                <!-- while loop goes through every skill row -->
                <option value="<?php echo $s['SkillID']; ?>">
                    <?php echo $s['SkillName']; ?>
                </option>
            <?php endwhile; ?>
        </select>

        <select name="level" required>
            <option value="">-- Select Level --</option>
            <option value="Beginner">Beginner</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Expert">Expert</option>
        </select>

        <button type="submit">Add Skill</button>
    </form>

    <div class="card" style="margin-top:20px">
        <h3>Your Skills</h3>
        <ul>
            <?php while ($row = mysqli_fetch_assoc($mySkills)): ?>
                <li>
                    <?php echo $row['SkillName']; ?> — <?php echo $row['SkillLevel']; ?>
                    <!-- clicking Remove adds ?delete=ID to the URL -->
                    <a href="skills.php?delete=<?php echo $row['SkillID']; ?>"
                       style="color:red; margin-left:10px">Remove</a>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>
</div>

</body>
</html>