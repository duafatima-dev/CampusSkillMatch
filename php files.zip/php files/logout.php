<?php
session_start();    // start session so we can access it
session_destroy();  // delete everything in the session
header("Location: login.php"); // send to login page
exit();
?>