<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}
include 'db.php';
$studentID = $_SESSION['student_id'];

// Apply to a project
if (isset($_GET['apply'])) {
    $projectID = $_GET['apply'];

    $check = mysqli_query($conn, "SELECT * FROM Application
                                  WHERE StudentID=$studentID AND ProjectID=$projectID");

    if (mysqli_num_rows($check) == 0) {
        mysqli_query($conn, "INSERT INTO Application (StudentID, ProjectID)
                             VALUES ($studentID, $projectID)");
        $msg = "Applied successfully!";
    } else {
        $msg = "You already applied to this project.";
    }
}

// Projects that MATCH this student's skills
$matched = mysqli_query($conn,
    "SELECT p.ProjectID, p.Title, p.Description, p.Deadline,
            sk.SkillName, st.Name AS PostedBy
     FROM Project p
     JOIN Skill sk ON p.RequiredSkillID = sk.SkillID
     JOIN Student st ON p.PostedBy = st.StudentID
     JOIN Student_Skills ss ON p.RequiredSkillID = ss.SkillID
     WHERE ss.StudentID = $studentID
     AND p.Status = 'Open'");

// All open projects
$projects = mysqli_query($conn,
    "SELECT p.ProjectID, p.Title, p.Description, p.Deadline,
            sk.SkillName, st.Name AS PostedBy
     FROM Project p
     JOIN Skill sk ON p.RequiredSkillID = sk.SkillID
     JOIN Student st ON p.PostedBy = st.StudentID
     WHERE p.Status = 'Open'");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Browse Projects</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <h2>Campus Skill Match</h2>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="skills.php">Skills</a></li>
        <li><a href="applications.php">Applications</a></li>
    </ul>
</nav>

<div class="container">

    <?php if (isset($msg)) echo "<p style='color:green'>$msg</p>"; ?>

    <!-- MATCHED PROJECTS -->
    <h2 style="color:green">⭐ Matched For You</h2>

    <?php if (mysqli_num_rows($matched) == 0): ?>
        <p style="color:gray">No matches yet — add more skills to get matched!</p>
    <?php endif; ?>

    <?php while ($p = mysqli_fetch_assoc($matched)): ?>
        <div class="card" style="border: 2px solid green">
            <h3><?php echo $p['Title']; ?></h3>
            <p><?php echo $p['Description']; ?></p>
            <p><strong>Skill Needed:</strong> <?php echo $p['SkillName']; ?></p>
            <p><strong>Deadline:</strong>     <?php echo $p['Deadline']; ?></p>
            <p><strong>Posted By:</strong>    <?php echo $p['PostedBy']; ?></p>
            <a href="browse.php?apply=<?php echo $p['ProjectID']; ?>" class="btn">Apply</a>
        </div>
    <?php endwhile; ?>

    <!-- ALL PROJECTS -->
    <h2 style="margin-top:30px">All Projects</h2>

    <?php while ($p = mysqli_fetch_assoc($projects)): ?>
        <div class="card">
            <h3><?php echo $p['Title']; ?></h3>
            <p><?php echo $p['Description']; ?></p>
            <p><strong>Skill Needed:</strong> <?php echo $p['SkillName']; ?></p>
            <p><strong>Deadline:</strong>     <?php echo $p['Deadline']; ?></p>
            <p><strong>Posted By:</strong>    <?php echo $p['PostedBy']; ?></p>
            <a href="browse.php?apply=<?php echo $p['ProjectID']; ?>" class="btn">Apply</a>
        </div>
    <?php endwhile; ?>

</div>
</body>
</html>